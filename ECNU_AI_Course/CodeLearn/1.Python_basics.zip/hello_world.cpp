# include<iostream>

int main(){
    std::cout << "hello world" << std::endl;
    std::cout << a << std::endl;
}