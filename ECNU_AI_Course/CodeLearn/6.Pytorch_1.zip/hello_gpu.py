import torch
import os

print(f"torch.cuda.is_available() = {torch.cuda.is_available()}")
print(f"torch.cuda.device_count() = {torch.cuda.device_count()}")
if 'CUDA_VISIBLE_DEVICES' in os.environ:
    print(f"os.environ['CUDA_VISIBLE_DEVICES'] = {os.environ['CUDA_VISIBLE_DEVICES']}")
else:
    print(f"没有设置环境变量 'CUDA_VISIBLE_DEVICES'")